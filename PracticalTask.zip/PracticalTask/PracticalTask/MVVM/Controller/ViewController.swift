//
//  ViewController.swift
//  PracticalTask
//
//  Created by Vikram on 01/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageCtrl: UIPageControl!
    
    var viewModel: ProductsViewModel? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pageCtrl.numberOfPages = 0
        
        self.viewModel = ProductsViewModel {
            self.collectionView.reloadData()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                let totalPage = Int(self.collectionView.contentSize.width / self.collectionView.bounds.width)
                self.pageCtrl.numberOfPages = totalPage
            }
        }
        self.viewModel?.fetchProductData()
    }
}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel?.products.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = self.viewModel?.productCell(for: indexPath, collectionView: collectionView) else {
            return UICollectionViewCell()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let colViewHeight = collectionView.bounds.height
        let colViewWidth = collectionView.bounds.width
        let cellWidth = (colViewWidth/3.0)
        
        let rows = Int(colViewHeight/cellWidth)
        print(rows)
        
        return CGSize(width: cellWidth, height: cellWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
}

extension ViewController: UIScrollViewDelegate {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let pageNumber = Int(scrollView.contentOffset.x / scrollView.bounds.width)
        print("Page No:", pageNumber)
        self.pageCtrl.currentPage = pageNumber
    }
    
}

class CellProduct: UICollectionViewCell {
    
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var productPrice: UILabel!
}

//
//  ProductsViewModel.swift
//  PracticalTask
//
//  Created by Vikram on 01/10/22.
//

import Foundation
import Alamofire
import Kingfisher

class ProductsViewModel {

    var products: [ProductsModel] = [] {
        didSet {
            self.refreshCompletion()
        }
    }
    
    private var refreshCompletion: (() -> Void)
    
    init(_ updateData: @escaping (() -> Void)) {
        self.refreshCompletion = updateData
    }
    
    func fetchProductData() {
        
        guard let url = URL(string: WebServicesConfig.EndPoints.appProducts) else {
            return
        }
        
        AF.request(url, method: .get).responseDecodable(of: [ProductsModel].self) { dataResponse in
         
            if let data = dataResponse.value {
                self.products = data
            }
        }
    }
    
    
    
}

extension ProductsViewModel {
    
    func productCell(for indexPath: IndexPath, collectionView: UICollectionView) -> UICollectionViewCell {
        let data = self.products[indexPath.row]
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellProduct", for: indexPath) as? CellProduct else {
            fatalError("Cell not registred or not defined in storyboard")
        }
        
        if let productPictures = data.productPictures, productPictures.count > 0 {
            cell.productImage.kf.setImage(with: URL(string: productPictures.first?.pictureURL ?? ""), placeholder: UIImage(named: "icn_product_placeholder"))
        } else {
            cell.productImage.image = UIImage(named: "icn_product_placeholder")
        }
        cell.productName.text = data.name
        cell.productPrice.text = "\(data.price ?? 0)"
        
        return cell
    }
}

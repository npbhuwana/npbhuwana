//
//  ProductsModel.swift
//  PracticalTask
//
//  Created by Vikram on 01/10/22.
//

import Foundation

struct ProductsModel: Codable {
    let id: Int?
    let name: String?
    let shortDescription, fullDescription, sku, gtin: String?
    let isGiftCard: Bool?
    let taxRate, manageInventoryMethodID, stockQuantity: Int?
    let price: Double?
    let customerEntersPrice: Bool?
    let minimumCustomerEnteredPrice, maximumCustomerEnteredPrice: Int?
    let productPictures, productFullSizePictures: [ProductPictureModel]?
    let productCategories: String?
    let productAttributes: [ProductAttributeModel]?
    let published: Bool?
    let displayOrder: Int?
    let showOnWebsite, showOnKiosk, showOnPosWeb, showOnPosMobile: Bool?
    let discountAmount, discountPercentage: Int?
    let usePercentage: Bool?

    enum CodingKeys: String, CodingKey {
        case id = "Id"
        case name = "Name"
        case shortDescription = "ShortDescription"
        case fullDescription = "FullDescription"
        case sku = "Sku"
        case gtin = "Gtin"
        case isGiftCard = "IsGiftCard"
        case taxRate = "TaxRate"
        case manageInventoryMethodID = "ManageInventoryMethodId"
        case stockQuantity = "StockQuantity"
        case price = "Price"
        case customerEntersPrice = "CustomerEntersPrice"
        case minimumCustomerEnteredPrice = "MinimumCustomerEnteredPrice"
        case maximumCustomerEnteredPrice = "MaximumCustomerEnteredPrice"
        case productPictures = "ProductPictures"
        case productFullSizePictures = "ProductFullSizePictures"
        case productCategories = "ProductCategories"
        case productAttributes = "ProductAttributes"
        case published = "Published"
        case displayOrder = "DisplayOrder"
        case showOnWebsite = "ShowOnWebsite"
        case showOnKiosk = "ShowOnKiosk"
        case showOnPosWeb = "ShowOnPosWeb"
        case showOnPosMobile = "ShowOnPosMobile"
        case discountAmount = "DiscountAmount"
        case discountPercentage = "DiscountPercentage"
        case usePercentage = "UsePercentage"
    }
}

// MARK: - ProductAttributeModel
struct ProductAttributeModel: Codable {
    let id, productAttributeID: Int?
    let name: String?
    let isRequired: Bool?
    let defaultValue: String?
    let attributeControlTypeID: Int?
    let attributeControlType: AttributeControlType?
    let values: [ProductAttributeValueModel]?
    let displayOrder: Int?

    enum CodingKeys: String, CodingKey {
        case id = "Id"
        case productAttributeID = "ProductAttributeId"
        case name = "Name"
        case isRequired = "IsRequired"
        case defaultValue = "DefaultValue"
        case attributeControlTypeID = "AttributeControlTypeId"
        case attributeControlType = "AttributeControlType"
        case values = "Values"
        case displayOrder = "DisplayOrder"
    }
}

enum AttributeControlType: String, Codable {
    case checkboxes = "Checkboxes"
    case dropdownList = "DropdownList"
    case multilineTextbox = "MultilineTextbox"
    case radioList = "RadioList"
    case readonlyCheckboxes = "ReadonlyCheckboxes"
    case textBox = "TextBox"
}

// MARK: - Value
struct ProductAttributeValueModel: Codable {
    let id: Int?
    let name: String?
    let colorSquaresRGB, priceAdjustment: String?
    let priceAdjustmentValue: Double?
    let isPreSelected: Bool?
    let pictureURL, fullSizePictureURL: String?

    enum CodingKeys: String, CodingKey {
        case id = "Id"
        case name = "Name"
        case colorSquaresRGB = "ColorSquaresRgb"
        case priceAdjustment = "PriceAdjustment"
        case priceAdjustmentValue = "PriceAdjustmentValue"
        case isPreSelected = "IsPreSelected"
        case pictureURL = "PictureUrl"
        case fullSizePictureURL = "FullSizePictureUrl"
    }
}

// MARK: - ProductPicture
struct ProductPictureModel: Codable {
    let pictureURL: String?
    let displayOrder: Int?

    enum CodingKeys: String, CodingKey {
        case pictureURL = "PictureUrl"
        case displayOrder = "DisplayOrder"
    }
}

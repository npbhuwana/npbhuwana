//
//  WebServicesConfig.swift
//  PracticalTask
//
//  Created by Vikram on 01/10/22.
//

import Foundation

class WebServicesConfig {
    
    static let baseURL = "https://cafe.shopfast.com/api/v1/"
    
    struct EndPoints {
        static var appProducts: String {
            return WebServicesConfig.baseURL + "catalog/products/app-products"
        }
    }
    
}
